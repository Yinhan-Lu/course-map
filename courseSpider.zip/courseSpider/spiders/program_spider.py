import requests
from bs4 import BeautifulSoup
import re
import json
import time
from urllib.parse import urljoin

def get_program_links_from_page(page_url, seen_programs):
    """
    Fetches program links and their names from a single page.
    Filters out programs that have been seen before.
    Returns list of tuples (url, program_name) for new programs only.
    """
    try:
        response = requests.get(page_url)
        if response.status_code != 200:
            print(f"Failed to fetch page {page_url}. Status code: {response.status_code}")
            return []
        
        soup = BeautifulSoup(response.text, "html.parser")
        program_info = []
        
        for link in soup.find_all("a", href=True):
            href = link["href"]
            text = link.text.strip()
            if text.startswith("Bachelor of") and "credits" in text:
                # Skip if we've seen this program before
                if text in seen_programs:
                    print(f"Skipping duplicate program: {text}")
                    continue
                
                full_url = urljoin(page_url, href)
                program_info.append((full_url, text))
                seen_programs.add(text)  # Add to set of seen programs
                print(f"Found new program: {text}")
        
        return program_info
    except Exception as e:
        print(f"Error processing page {page_url}: {str(e)}")
        return []

def extract_course_data(program_url, program_name):
    """
    Extracts course data from a specific program page.
    """
    try:
        response = requests.get(program_url)
        if response.status_code != 200:
            print(f"Failed to fetch program page: {program_url}")
            return None

        soup = BeautifulSoup(response.text, "html.parser")
        course_pattern = re.compile(r"([A-Z]{4} \d{3}) (.+?) \((\d+) credits\)")
        
        courses = []
        potential_courses = soup.find_all("a", href=True)
        
        for item in potential_courses:
            course_text = item.text.strip()
            match = course_pattern.match(course_text)
            if match:
                course_number, course_title, course_credits = match.groups()
                courses.append({
                    "course_number": course_number,
                    "course_title": course_title,
                    "credits": int(course_credits),
                    "link": urljoin(program_url, item["href"])
                })

        return {
            "program": program_name,
            "program_url": program_url,
            "courses": courses
        }
    
    except Exception as e:
        print(f"Error processing {program_url}: {str(e)}")
        return None

def main():
    base_url = "https://www.mcgill.ca/study/2024-2025/programs/search"
    all_programs_data = []
    total_pages = 62
    programs_processed = 0
    seen_programs = set()  # Set to track programs we've already seen
    
    print("Starting to fetch programs from all pages...")
    
    # Process each page
    for page in range(total_pages + 1):
        page_url = f"{base_url}?search_api_views_fulltext=&sort_by=search_api_relevance&page={page}"
        print(f"\nProcessing page {page}/{total_pages}")
        
        # Get program links and names from current page, excluding duplicates
        program_info = get_program_links_from_page(page_url, seen_programs)
        print(f"Found {len(program_info)} new programs on page {page}")
        
        # Process each new program on the current page
        for i, (program_url, program_name) in enumerate(program_info, 1):
            programs_processed += 1
            print(f"\nProcessing program {i}/{len(program_info)} on page {page}")
            print(f"Program: {program_name}")
            print(f"URL: {program_url}")
            
            # Add delay to be respectful to the server
            time.sleep(1)
            
            program_data = extract_course_data(program_url, program_name)
            if program_data:
                print(f"Successfully extracted courses for: {program_name}")
                print(f"Found {len(program_data['courses'])} courses")
                all_programs_data.append(program_data)
            else:
                print(f"Failed to extract courses from: {program_name}")
        
        # Save progress after each page
        output_file = "mcgill_programs_courses.json"
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(all_programs_data, f, indent=4, ensure_ascii=False)
        
        print(f"\nProgress saved. Completed page {page}/{total_pages}")
        print(f"Total unique programs processed so far: {len(seen_programs)}")
        print(f"Total programs with successful data extraction: {len(all_programs_data)}")
        
        # Add delay between pages
        if page < total_pages:
            print("Waiting before processing next page...")
            time.sleep(2)
    
    print(f"\nAll processing complete. Final data saved to {output_file}")
    print(f"Total unique programs found: {len(seen_programs)}")
    print(f"Total programs with successful data extraction: {len(all_programs_data)}")

if __name__ == "__main__":
    main()