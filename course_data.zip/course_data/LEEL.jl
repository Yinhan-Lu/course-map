{"name": "LEEL 571 Transnational Labour Law (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/leel-571", "subject": "LEEL"}
{"name": "LEEL 570 Employment Law (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/leel-570", "subject": "LEEL"}
{"name": "LEEL 582 Law and Poverty (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/leel-582", "subject": "LEEL"}
{"name": "LEEL 369 Labour Law (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/leel-369", "subject": "LEEL"}
