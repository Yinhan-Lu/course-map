{"name": "AECH 119 General Chemistry Laboratory 2 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aech-119", "subject": "AECH"}
{"name": "AECH 111 General Chemistry 2 (4 credits)", "prereq": ["fdsc-110", "aech-110"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aech-111", "subject": "AECH"}
{"name": "AECH 118 General Chemistry Laboratory 1 (1 credit)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aech-118", "subject": "AECH"}
{"name": "AECH 110 General Chemistry 1 (4 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aech-110", "subject": "AECH"}
