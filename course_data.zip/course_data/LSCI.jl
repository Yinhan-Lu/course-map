{"name": "LSCI 451 Research Project 1 (3 credits)", "prereq": ["para-438"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/lsci-451", "subject": "LSCI"}
{"name": "LSCI 402 Honours Research Project 2 (6 credits)", "prereq": ["lsci-401"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/lsci-402", "subject": "LSCI"}
{"name": "LSCI 452 Research Project 2 (3 credits)", "prereq": ["lsci-451"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/lsci-452", "subject": "LSCI"}
{"name": "LSCI 401 Honours Research Project\r 1 (6 credits)", "prereq": ["aehm-205"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/lsci-401", "subject": "LSCI"}
{"name": "LSCI 230 Introductory Microbiology (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/lsci-230", "subject": "LSCI"}
{"name": "LSCI 204 Genetics (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/lsci-204", "subject": "LSCI"}
{"name": "LSCI 211 Biochemistry 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/lsci-211", "subject": "LSCI"}
{"name": "LSCI 202 Molecular Cell Biology (3 credits)", "prereq": ["lsci-211", "fdsc-230"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/lsci-202", "subject": "LSCI"}
