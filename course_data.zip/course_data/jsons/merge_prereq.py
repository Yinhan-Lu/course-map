import json
import os

def load_json_file(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)

def save_json_file(data, filepath):
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=4)

def create_course_prereq_map():
    # Dictionary to store all course prerequisites
    course_prereq_map = {}
    
    # Get all department JSON files
    json_dir = 'course_data/jsons'
    dept_files = [f for f in os.listdir(json_dir) if f.endswith('.json') and f != 'programs.json']
    
    # Load prerequisites from each department file
    for dept_file in dept_files:
        dept_data = load_json_file(os.path.join(json_dir, dept_file))
        for course in dept_data:
            course_number = course.get('course_number')
            if course_number:
                course_prereq_map[course_number] = course.get('prerequisites', [])
    
    return course_prereq_map

def update_programs_with_prerequisites():
    # Load the prerequisite mapping
    prereq_map = create_course_prereq_map()
    
    # Load programs.json
    programs_path = 'course_data/jsons/programs.json'
    programs_data = load_json_file(programs_path)
    
    # Update each program's courses with prerequisites
    for program in programs_data:
        for course in program['courses']:
            course_number = course.get('course_number')
            if course_number in prereq_map:
                course['prerequisites'] = prereq_map[course_number]
            else:
                course['prerequisites'] = []
    
    # Save updated programs.json
    save_json_file(programs_data, programs_path)

if __name__ == "__main__":
    update_programs_with_prerequisites()