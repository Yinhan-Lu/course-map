{"name": "SURG 402D1 Surgery Clerkship (4 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/surg-402d1", "subject": "SURG"}
{"name": "SURG 403 Surgery Sub-Specialty - Senior Clerkships (4 credits)", "prereq": ["surg-401"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/surg-403", "subject": "SURG"}
{"name": "SURG 402 Surgery Clerkship (8 credits)", "term": "Fall 2024, Winter 2025, Summer 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/surg-402", "subject": "SURG"}
{"name": "SURG 402D2 Surgery Clerkship (4 credits)", "prereq": ["surg-402d1"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/surg-402d2", "subject": "SURG"}
{"name": "SURG 301 TCP Surgery (4 credits)", "term": "Winter 2025, Summer 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/surg-301", "subject": "SURG"}
