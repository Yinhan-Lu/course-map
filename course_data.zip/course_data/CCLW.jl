{"name": "CCLW 611 Business Law Concepts (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cclw-611", "subject": "CCLW"}
{"name": "CCLW 300 Public Administration and Law for Indigenous Peoples (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/cclw-300", "subject": "CCLW"}
{"name": "CCLW 205 Introduction to Business Law (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cclw-205", "subject": "CCLW"}
