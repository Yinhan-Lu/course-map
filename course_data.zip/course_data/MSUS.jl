{"name": "MSUS 402 Systems Thinking and Sustainability (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/msus-402", "subject": "MSUS"}
{"name": "MSUS 401 Sustainability Consulting (3 credits)", "prereq": ["mgpo-440"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/msus-401", "subject": "MSUS"}
{"name": "MSUS 400 Independent Studies in Sustainability (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/msus-400", "subject": "MSUS"}
{"name": "MSUS 497 Internship in Sustainability (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/msus-497", "subject": "MSUS"}
{"name": "MSUS 434 Topics in Sustainability 1 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/msus-434", "subject": "MSUS"}
{"name": "MSUS 435 Topics in Sustainability 2 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/msus-435", "subject": "MSUS"}
