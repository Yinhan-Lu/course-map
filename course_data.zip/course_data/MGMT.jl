{"name": "MGMT 720 Research Paper (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mgmt-720", "subject": "MGMT"}
{"name": "MGMT 707 Research Methodology (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/mgmt-707", "subject": "MGMT"}
{"name": "MGMT 708 General Research Methods (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/mgmt-708", "subject": "MGMT"}
{"name": "MGMT 710 Seminars in Management 1 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/mgmt-710", "subject": "MGMT"}
{"name": "MGMT 714 Seminars in Management 2 (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mgmt-714", "subject": "MGMT"}
{"name": "MGMT 709 Designing for Causal Inference (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mgmt-709", "subject": "MGMT"}
{"name": "MGMT 701 Comprehensive Examination", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mgmt-701", "subject": "MGMT"}
