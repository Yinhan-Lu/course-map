{"name": "CEAP 672 Selected Topics in Communication 2 (1 credit)", "term": "This course is not scheduled for the 2020-2021 academic year.", "link": "https://mcgill.ca/study/2020-2021/courses/ceap-672", "subject": "CEAP"}
{"name": "CEAP 671 Selected Topics in Communication 1 (1 credit)", "term": "This course is not scheduled for the 2020-2021 academic year.", "link": "https://mcgill.ca/study/2020-2021/courses/ceap-671", "subject": "CEAP"}
{"name": "CEAP 665 Literature Review 2: Establishing Scholarly Niches (1 credit)", "term": "Fall 2020, Winter 2021", "link": "https://mcgill.ca/study/2020-2021/courses/ceap-665", "subject": "CEAP"}
{"name": "CEAP 661 Literature Review 1: Summary and Critique (1 credit)", "term": "Fall 2020, Winter 2021", "link": "https://mcgill.ca/study/2020-2021/courses/ceap-661", "subject": "CEAP"}
{"name": "CEAP 643 Literature Reviews and Scholarly Niches (1 credit)", "term": "This course is not scheduled for the 2020-2021 academic year.", "link": "https://mcgill.ca/study/2020-2021/courses/ceap-643", "subject": "CEAP"}
{"name": "CEAP 652 Fundamentals of Academic Presentations (1 credit)", "term": "Fall 2020, Winter 2021", "link": "https://mcgill.ca/study/2020-2021/courses/ceap-652", "subject": "CEAP"}
{"name": "CEAP 642 Cornerstones of Academic Writing (1 credit)", "term": "Fall 2020, Winter 2021", "link": "https://mcgill.ca/study/2020-2021/courses/ceap-642", "subject": "CEAP"}
{"name": "CEAP 250 Research Essay & Rhetoric (3 credits)", "term": "Fall 2020, Winter 2021", "link": "https://mcgill.ca/study/2020-2021/courses/ceap-250", "subject": "CEAP"}
{"name": "CEAP 150 Critical Analysis and Composition (3 credits)", "term": "Fall 2020", "link": "https://mcgill.ca/study/2020-2021/courses/ceap-150", "subject": "CEAP"}
