{"name": "FIGM MMR MMR International Study Trip", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/figm-mmr", "subject": "FIGM"}
{"name": "FIGM TRP", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/figm-trp", "subject": "FIGM"}
{"name": "FIGM MMF MMF International Study Trip", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/figm-mmf", "subject": "FIGM"}
