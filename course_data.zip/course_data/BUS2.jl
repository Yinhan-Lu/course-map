{"name": "BUS2 531 Banking Law (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-531", "subject": "BUS2"}
{"name": "BUS2 504 Securities Regulation (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-504", "subject": "BUS2"}
{"name": "BUS2 561 Insurance (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-561", "subject": "BUS2"}
{"name": "BUS2 505 Corporate Finance (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-505", "subject": "BUS2"}
{"name": "BUS2 503 Business Organizations (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-503", "subject": "BUS2"}
{"name": "BUS2 502 Intellectual and Industrial Property (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-502", "subject": "BUS2"}
{"name": "BUS2 365D2 Business Associations (2 credits)", "prereq": ["bus2-365d1"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-365d2", "subject": "BUS2"}
{"name": "BUS2 365D1 Business Associations (2 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-365d1", "subject": "BUS2"}
{"name": "BUS2 365 Business Associations (4 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-365", "subject": "BUS2"}
{"name": "BUS2 501 Patent Theory and Policy (3 credits)", "prereq": ["bus2-463"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bus2-501", "subject": "BUS2"}
