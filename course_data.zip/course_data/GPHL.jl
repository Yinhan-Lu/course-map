{"name": "GPHL 200 Foundations in Population and Global Health (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/gphl-200", "subject": "GPHL"}
{"name": "GPHL 201 Population and Global Health Ethics (3 credits)", "prereq": ["gphl-200"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/gphl-201", "subject": "GPHL"}
