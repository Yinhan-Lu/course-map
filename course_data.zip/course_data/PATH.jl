{"name": "PATH 701 Comprehensive Examination - Ph.D. Candidates", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-701", "subject": "PATH"}
{"name": "PATH 692 M.Sc. Thesis Research Project 3 (12 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-692", "subject": "PATH"}
{"name": "PATH 691 M.Sc. Thesis Research Project 2 (9 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-691", "subject": "PATH"}
{"name": "PATH 622 Research Seminar 2 (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-622", "subject": "PATH"}
{"name": "PATH 690 M.Sc. Thesis Research Project 1 (9 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-690", "subject": "PATH"}
{"name": "PATH 653 Reading and Conference (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-653", "subject": "PATH"}
{"name": "PATH 620 Research Seminar 1 (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-620", "subject": "PATH"}
{"name": "PATH 614 Research Topics in Pathology 2 (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-614", "subject": "PATH"}
{"name": "PATH 607 Biochemical Pathology (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-607", "subject": "PATH"}
{"name": "PATH 613 Research Topics in Pathology 1 (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-613", "subject": "PATH"}
{"name": "PATH 652 Molecular Biology of Disease (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-652", "subject": "PATH"}
{"name": "PATH 504 Disease in Depth (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-504", "subject": "PATH"}
{"name": "PATH 300 Human Disease (3 credits)", "prereq": ["biol-200", "biol-201", "bioc-212", "phgy-209", "phgy-210"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-300", "subject": "PATH"}
{"name": "PATH 396 Undergraduate Research Project in\r Pathology (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/path-396", "subject": "PATH"}
