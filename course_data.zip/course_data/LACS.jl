{"name": "LACS 497 Research Seminar: Latin America and the Caribbean (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/lacs-497", "subject": "LACS"}
{"name": "LACS 499 Internship: Latin America and Caribbean Studies (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/lacs-499", "subject": "LACS"}
{"name": "LACS 480 Latin American and Caribbean Studies Reading Course (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/lacs-480", "subject": "LACS"}
{"name": "LACS 498 Honours Thesis (3 credits)", "prereq": ["lacs-497"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/lacs-498", "subject": "LACS"}
