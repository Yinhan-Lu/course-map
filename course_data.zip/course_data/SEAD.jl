{"name": "SEAD 660 Strategies for\r Sustainability\r (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-660", "subject": "SEAD"}
{"name": "SEAD 670 Collaborative Design for Sustainability (5 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-670", "subject": "SEAD"}
{"name": "SEAD 602 Sustainability Research 2\r (3 credits)", "prereq": ["sead-600"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-602", "subject": "SEAD"}
{"name": "SEAD 600 Sustainability Research 1 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-600", "subject": "SEAD"}
{"name": "SEAD 500 Foundations of Sustainability for Engineering and Design (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-500", "subject": "SEAD"}
{"name": "SEAD 550 Decision-Making for Sustainability in Engineering and Design (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-550", "subject": "SEAD"}
{"name": "SEAD 540 Industrial Ecology and Systems (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-540", "subject": "SEAD"}
{"name": "SEAD 530 Economics for Sustainability in Engineering and Design (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-530", "subject": "SEAD"}
{"name": "SEAD 520 Life Cycle-Based Environmental\r Footprinting\r (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-520", "subject": "SEAD"}
{"name": "SEAD 515 Climate Change Adaptation and Engineering Infrastructure\r (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-515", "subject": "SEAD"}
{"name": "SEAD 510 Energy Analysis (4 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/sead-510", "subject": "SEAD"}
