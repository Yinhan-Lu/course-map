{"name": "CGMG 445 Ethical Issues in Business\r Practices (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cgmg-445", "subject": "CGMG"}
{"name": "CGMG 305 Managing in Public and Non-Profit Organizations (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cgmg-305", "subject": "CGMG"}
{"name": "CGMG 319 International Business Practices (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/cgmg-319", "subject": "CGMG"}
{"name": "CGMG 318 Selling Models and Business Negotiation (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cgmg-318", "subject": "CGMG"}
{"name": "CGMG 282 Introduction to Business (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cgmg-282", "subject": "CGMG"}
{"name": "CGMG 210 Fundamentals of Project Management (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cgmg-210", "subject": "CGMG"}
