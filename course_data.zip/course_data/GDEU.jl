{"name": "GDEU 2PGM", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/gdeu-2pgm", "subject": "GDEU"}
{"name": "GDEU THES", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/gdeu-thes", "subject": "GDEU"}
{"name": "GDEU DSRT", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/gdeu-dsrt", "subject": "GDEU"}
