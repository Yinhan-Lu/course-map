import json

# Function to process and restructure each course entry
def restructure_course(data):
    # Helper function to format prerequisites
    def format_prerequisites(prereqs):
        return [prereq.upper().replace("-", " ") for prereq in prereqs]

    # More robust credit extraction
    name_parts = data["name"].split()
    credits = 0.0
    
    # Look for the credit value in parentheses
    for i, part in enumerate(name_parts):
        if '(' in part and 'credit' in ''.join(name_parts[i:i+2]).lower():
            try:
                # Extract number from "(X credits)"
                credit_str = part.replace("(", "").replace(")", "").replace("credit", "").replace("s", "").strip()
                credits = int(credit_str)
                break
            except ValueError:
                continue

    # Extract course number (first two parts)
    course_number = " ".join(name_parts[:2])
    # Extract course title (everything after the second part)
    course_title = " ".join(name_parts[2:])

    course = {
        "course_number": course_number,
        "course_title": course_title,
        "credits": credits,
        "link": data["link"],
        "prerequisites": format_prerequisites(data.get("prereq", []))  # Format prerequisites
    }
    return course

# Read the .jl file and convert it to a list of structured dictionaries
def convert_jl_to_json(jl_file, json_file):
    courses = []
    with open(jl_file, "r", encoding="utf-8") as file:
        for line in file:
            data = json.loads(line.strip())  # Parse each line as JSON
            structured_course = restructure_course(data)
            courses.append(structured_course)
    
    # Write to the .json file
    with open(json_file, "w", encoding="utf-8") as file:
        json.dump(courses, file, indent=4)

# Input and output file names
jl_file_comp = "course_data/COMP.jl"
json_file_comp = "course_data/COMP.json"
jl_file_math = "course_data/MATH.jl"
json_file_math = "MATH.json"
jl_file_phys = "course_data/PHYS.jl"
json_file_phys = "course_data/PHYS.json"
jl_file_biol = "course_data/BIOL.jl"
json_file_biol = "course_data/BIOL.json"
jl_file_chem = "course_data/CHEM.jl"
json_file_chem = "course_data/CHEM.json"

# Run the conversion
convert_jl_to_json(jl_file_comp, json_file_comp)
convert_jl_to_json(jl_file_math, json_file_math)
convert_jl_to_json(jl_file_phys, json_file_phys)
convert_jl_to_json(jl_file_biol, json_file_biol)
convert_jl_to_json(jl_file_chem, json_file_chem)
