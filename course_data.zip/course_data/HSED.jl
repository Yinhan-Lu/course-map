{"name": "HSED 702D2 Advanced Topics in Health Sciences Education (3 credits)", "prereq": ["hsed-702d1"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/hsed-702d2", "subject": "HSED"}
{"name": "HSED 703 Research Design for Health Sciences Education (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/hsed-703", "subject": "HSED"}
{"name": "HSED 704 Advanced Qualitative Research (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/hsed-704", "subject": "HSED"}
{"name": "HSED 701 PhD Comprehensive Examination", "prereq": ["hsed-702", "hsed-703"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/hsed-701", "subject": "HSED"}
{"name": "HSED 702D1 Advanced Topics in Health Sciences Education (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/hsed-702d1", "subject": "HSED"}
{"name": "HSED 601 Introduction to Leadership in Health\r Sciences Education\r (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/hsed-601", "subject": "HSED"}
{"name": "HSED 602 Introduction to Scholarship in Health Sciences Education (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/hsed-602", "subject": "HSED"}
{"name": "HSED 625 Introduction to Qualitative Research in Health (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/hsed-625", "subject": "HSED"}
