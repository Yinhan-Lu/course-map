{"name": "OPTH 300 TCP Ophthalmology (1 credit)", "term": "Winter 2025, Summer 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/opth-300", "subject": "OPTH"}
