{"name": "ASPL 701 Comprehensive - Air/Space Law", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-701", "subject": "ASPL"}
{"name": "ASPL 694 Master's Thesis 5 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-694", "subject": "ASPL"}
{"name": "ASPL 692 Master's Thesis 3 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-692", "subject": "ASPL"}
{"name": "ASPL 693 Master's Thesis 4 (12 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-693", "subject": "ASPL"}
{"name": "ASPL 691 Master's Thesis 2 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-691", "subject": "ASPL"}
{"name": "ASPL 690 Master's Thesis 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-690", "subject": "ASPL"}
{"name": "ASPL 657 Research Project 3 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-657", "subject": "ASPL"}
{"name": "ASPL 655 Research Project 1 (15 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-655", "subject": "ASPL"}
{"name": "ASPL 639 Government Regulation of Space Activities (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-639", "subject": "ASPL"}
{"name": "ASPL 638 Law of Space Applications (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-638", "subject": "ASPL"}
{"name": "ASPL 636 Private International Air Law (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-636", "subject": "ASPL"}
{"name": "ASPL 656 Research Project 2 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-656", "subject": "ASPL"}
{"name": "ASPL 637 Space Law: General Principles (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-637", "subject": "ASPL"}
{"name": "ASPL 633 Public International Air Law (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-633", "subject": "ASPL"}
{"name": "ASPL 632D2 Comparative Air Law (1.5 credits)", "prereq": ["aspl-632d1"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-632d2", "subject": "ASPL"}
{"name": "ASPL 613 Government Regulation of Air Transport (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-613", "subject": "ASPL"}
{"name": "ASPL 632D1 Comparative Air Law (1.5 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-632d1", "subject": "ASPL"}
{"name": "ASPL 614 Airline Business and Law (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-614", "subject": "ASPL"}
{"name": "ASPL 632 Comparative Air Law (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aspl-632", "subject": "ASPL"}
