{"name": "YCFN N03", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/ycfn-n03", "subject": "YCFN"}
