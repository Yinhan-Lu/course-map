{"name": "LIBA 490 Honours Thesis (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/liba-490", "subject": "LIBA"}
{"name": "LIBA 202 Introduction to Liberal Arts (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/liba-202", "subject": "LIBA"}
{"name": "LIBA 395 Individual Reading Course (3 credits)", "prereq": ["liba-202"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/liba-395", "subject": "LIBA"}
{"name": "LIBA 402 Seminar in Liberal Arts (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/liba-402", "subject": "LIBA"}
