{"name": "CMR2 650 Digital Marketing\r Management (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-650", "subject": "CMR2"}
{"name": "CMR2 691 Marketing Strategy (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-691", "subject": "CMR2"}
{"name": "CMR2 668 Buyer Behaviour\r (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-668", "subject": "CMR2"}
{"name": "CMR2 664 Integrated Marketing\r Communications (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-664", "subject": "CMR2"}
{"name": "CMR2 643 Marketing of\r Services (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-643", "subject": "CMR2"}
{"name": "CMR2 590 Topics in Marketing (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-590", "subject": "CMR2"}
{"name": "CMR2 573 Digital Marketing Communications (3 credits)", "prereq": ["cmis-543", "cmis-544", "cmis-549"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-573", "subject": "CMR2"}
{"name": "CMR2 566 Global Marketing Management (3 credits)", "prereq": ["cmr2-542", "cmr2-642", "cmr2-548", "cmr2-648", "cms2-521", "cms2-621"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-566", "subject": "CMR2"}
{"name": "CMR2 642 Marketing Principles and\r Applications (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-642", "subject": "CMR2"}
{"name": "CMR2 648 Marketing Research and\r Reporting (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cmr2-648", "subject": "CMR2"}
