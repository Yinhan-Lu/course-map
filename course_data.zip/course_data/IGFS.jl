{"name": "IGFS 611 Advanced Issues on Development, Food and Agriculture (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/igfs-611", "subject": "IGFS"}
