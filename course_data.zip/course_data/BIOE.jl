{"name": "BIOE 694 Independent Studies 3 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-694", "subject": "BIOE"}
{"name": "BIOE 693D1 M.Sc. Thesis (6 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-693d1", "subject": "BIOE"}
{"name": "BIOE 693 M.Sc. Thesis (12 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-693", "subject": "BIOE"}
{"name": "BIOE 693D2 M.Sc. Thesis (6 credits)", "prereq": ["bioe-693d1"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-693d2", "subject": "BIOE"}
{"name": "BIOE 692D2 M.Sc. Thesis Research Progress Report (3 credits)", "prereq": ["bioe-692d1"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-692d2", "subject": "BIOE"}
{"name": "BIOE 692 M.Sc. Thesis Research Progress Report (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-692", "subject": "BIOE"}
{"name": "BIOE 692D1 M.Sc. Thesis Research Progress Report (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-692d1", "subject": "BIOE"}
{"name": "BIOE 691 M.Sc. Thesis Research Proposal (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-691", "subject": "BIOE"}
{"name": "BIOE 690 M.Sc. Thesis Literature Survey (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-690", "subject": "BIOE"}
{"name": "BIOE 687 Directed Readings 2 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-687", "subject": "BIOE"}
{"name": "BIOE 686 Directed Readings 1 (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-686", "subject": "BIOE"}
{"name": "BIOE 681 Bioethics Practicum (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-681", "subject": "BIOE"}
{"name": "BIOE 680 Bioethical Theory (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/bioe-680", "subject": "BIOE"}
