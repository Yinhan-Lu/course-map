{"name": "WMST 620 Current Topics 2 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/wmst-620", "subject": "WMST"}
{"name": "WMST 610 Current Topics 1 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/wmst-610", "subject": "WMST"}
{"name": "WMST 601 Feminist Theories and Methods (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/wmst-601", "subject": "WMST"}
{"name": "WMST 602 Feminist Research Symposium (3 credits)", "prereq": ["wmst-601"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/wmst-602", "subject": "WMST"}
