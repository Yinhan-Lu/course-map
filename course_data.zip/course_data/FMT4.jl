{"name": "FMT4 013D2 Agricultural Internship (152-VSN-MC) (1 credit)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-013d2", "subject": "FMT4"}
{"name": "FMT4 015 Forest Management (152-VSQ-MC) (1.33 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-015", "subject": "FMT4"}
{"name": "FMT4 018 Enterprise Management 1 (152-VSU-MC) (2.33 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-018", "subject": "FMT4"}
{"name": "FMT4 014 Marketing Strategies (152-VSP-MC) (2 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-014", "subject": "FMT4"}
{"name": "FMT4 017 Agricultural Systems (152-VST-MC) (1.33 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-017", "subject": "FMT4"}
{"name": "FMT4 016 Budgeting and Administration (152-VSR-MC) (2 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-016", "subject": "FMT4"}
{"name": "FMT4 013 Agricultural Internship (152-VSN-MC) (2 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-013", "subject": "FMT4"}
{"name": "FMT4 013D1 Agricultural Internship (152-VSN-MC) (1 credit)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-013d1", "subject": "FMT4"}
{"name": "FMT4 008 Animal Genetics and Nutrition (152-VSH-MC) (2.33 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-008", "subject": "FMT4"}
{"name": "FMT4 011 Farm Accounting (152-VSL-MC) (2 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-011", "subject": "FMT4"}
{"name": "FMT4 010 Winter Stage (152-VSK-MC) (1.33 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-010", "subject": "FMT4"}
{"name": "FMT4 007 Health and Safety (152-VSG-MC) (2 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-007", "subject": "FMT4"}
{"name": "FMT4 012 Machinery Maintenance (152-VSM-MC) (1.67 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-012", "subject": "FMT4"}
{"name": "FMT4 009 Soil Fertility (152-VSJ-MC) (2 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-009", "subject": "FMT4"}
{"name": "FMT4 006 Pesticides and the Environment (152-VSF-MC) (1.33 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-006", "subject": "FMT4"}
{"name": "FMT4 005 Introduction to Plant Science (152-VSE-MC) (2.33 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-005", "subject": "FMT4"}
{"name": "FMT4 004 Animal Physiology and Anatomy (152-VSD-MC) (1.33 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-004", "subject": "FMT4"}
{"name": "FMT4 003 Information Management (152-VSC-MC) (1.33 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-003", "subject": "FMT4"}
{"name": "FMT4 002 Soil Tillage (152-VSB-MC) (1.67 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-002", "subject": "FMT4"}
{"name": "FMT4 001 Fall Stage (152-VSA-MC) (1.33 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-001", "subject": "FMT4"}
{"name": "FMT4 035 Field Crop Management 1 (152-VTM-MC) (2.67 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-035", "subject": "FMT4"}
{"name": "FMT4 036 Field Crop Management 2 (152-VTN-MC) (2.67 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-036", "subject": "FMT4"}
{"name": "FMT4 034 Greenhouse Crop Production (152-VTL-MC) (2.67 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-034", "subject": "FMT4"}
{"name": "FMT4 030 Swine and Poultry Management (152-VTG-MC) (2.67 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-030", "subject": "FMT4"}
{"name": "FMT4 033 Vegetable and Fruit Crops (152-VTK-MC) (2.67 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-033", "subject": "FMT4"}
{"name": "FMT4 031 Beef and Sheep Management (152-VTH-MC) (2.67 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-031", "subject": "FMT4"}
{"name": "FMT4 028 Dairy Replacement Management (152-VTE-MC) (2.67 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-028", "subject": "FMT4"}
{"name": "FMT4 032 Independent Study in Animal Production(152-VTJ-MC) (2.67 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-032", "subject": "FMT4"}
{"name": "FMT4 027 Precision Agriculture (152-VTD-MC) (1.33 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-027", "subject": "FMT4"}
{"name": "FMT4 026 Human Resources  (152-VTC-MC) (1.67 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-026", "subject": "FMT4"}
{"name": "FMT4 029 Dairy Performance Management (152-VTF-MC) (2.67 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-029", "subject": "FMT4"}
{"name": "FMT4 025 Enterprise Management 3 (152-VTB-MC) (2.33 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-025", "subject": "FMT4"}
{"name": "FMT4 022 Equipment Management (152-VSY-MC) (1.67 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-022", "subject": "FMT4"}
{"name": "FMT4 021 Enterprise Management 2 (152-VSX-MC) (2.67 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-021", "subject": "FMT4"}
{"name": "FMT4 024 Farm Building Development (152-VTA-MC) (1.67 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-024", "subject": "FMT4"}
{"name": "FMT4 023 Building Management (152-VSZ-MC) (1.33 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-023", "subject": "FMT4"}
{"name": "FMT4 019 Nutrient Management Plan (152-VSV-MC) (2 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-019", "subject": "FMT4"}
{"name": "FMT4 020 Conservation of Soil and Water (152-VSW-MC) (2 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-020", "subject": "FMT4"}
{"name": "FMT4 018D2 Enterprise Management 1 (152-VSU-MC) (1.17 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-018d2", "subject": "FMT4"}
{"name": "FMT4 018D1 Enterprise Management 1 (152-VSU-MC) (1.16 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-018d1", "subject": "FMT4"}
{"name": "FMT4 037 Independent Study in Crop Production (152-VTP-MC) (2.67 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fmt4-037", "subject": "FMT4"}
