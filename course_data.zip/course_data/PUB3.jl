{"name": "PUB3 515 Canadian Charter of Rights and Freedoms (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/pub3-515", "subject": "PUB3"}
{"name": "PUB3 116 Foundations (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/pub3-116", "subject": "PUB3"}
