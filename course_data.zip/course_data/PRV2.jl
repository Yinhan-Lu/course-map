{"name": "PRV2 500 Children and the Law (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/prv2-500", "subject": "PRV2"}
{"name": "PRV2 270 Law of Persons (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/prv2-270", "subject": "PRV2"}
