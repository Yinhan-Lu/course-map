{"name": "CPAG 625 Public Finance, Budgeting\r and Reporting (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-625", "subject": "CPAG"}
{"name": "CPAG 410 Strategic Planning and Implementation (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-410", "subject": "CPAG"}
{"name": "CPAG 620 Leadership and Governance in Public Organizations.\r (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-620", "subject": "CPAG"}
{"name": "CPAG 615 Public Regulations and Ethics in the Public Sector (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-615", "subject": "CPAG"}
{"name": "CPAG 610 Current Issues in Public\r Sector Management (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-610", "subject": "CPAG"}
{"name": "CPAG 600 Lean Operations in Public Services (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-600", "subject": "CPAG"}
{"name": "CPAG 400 Diversity, Equity, and Inclusion Management (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-400", "subject": "CPAG"}
{"name": "CPAG 305 Current Issues in Public Sector Administration (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-305", "subject": "CPAG"}
{"name": "CPAG 300 Lean Operational Practices in Public Services (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-300", "subject": "CPAG"}
{"name": "CPAG 225 Foundations of Public Regulations and Ethics in Public Sector (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-225", "subject": "CPAG"}
{"name": "CPAG 220 Fundamentals of Public Finance, Budgeting and Reporting (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/cpag-220", "subject": "CPAG"}
