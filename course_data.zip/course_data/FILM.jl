{"name": "FILM 499 Internship: World Cinemas (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/film-499", "subject": "FILM"}
