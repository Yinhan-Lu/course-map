{"name": "CEC2 532 Business Economics (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/cec2-532", "subject": "CEC2"}
{"name": "CEC2 632 Business Economics (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cec2-632", "subject": "CEC2"}
