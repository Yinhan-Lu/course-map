{"name": "MHEC 602 Outils et pratiques de gestion (4 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mhec-602", "subject": "MHEC"}
{"name": "MHEC 601 Excellence op\u00e9rationnelle (4 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mhec-601", "subject": "MHEC"}
{"name": "MHEC 600 Cr\u00e9ation de valeur (4 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mhec-600", "subject": "MHEC"}
