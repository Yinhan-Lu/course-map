{"name": "FIGA NU0 Arts U0 Advising", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/figa-nu0", "subject": "FIGA"}
