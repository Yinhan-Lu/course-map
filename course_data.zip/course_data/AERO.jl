{"name": "AERO 460D1 Aerospace Project (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aero-460d1", "subject": "AERO"}
{"name": "AERO 460D2 Aerospace Project (3 credits)", "prereq": ["aero-460d1"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aero-460d2", "subject": "AERO"}
{"name": "AERO 401 Introduction to Aerospace Engineering (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aero-401", "subject": "AERO"}
{"name": "AERO 420 Introduction to Aerospace Design (3 credits)", "prereq": ["aero-401"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aero-420", "subject": "AERO"}
{"name": "AERO 410 Aerospace Design and Certification Process (3 credits)", "prereq": ["aero-401"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aero-410", "subject": "AERO"}
