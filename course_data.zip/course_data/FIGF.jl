{"name": "FIGF PMCO", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/figf-pmco", "subject": "FIGF"}
{"name": "FIGF PMCE", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/figf-pmce", "subject": "FIGF"}
