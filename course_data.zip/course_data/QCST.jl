{"name": "QCST 200 Introduction to the Study of Quebec (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/qcst-200", "subject": "QCST"}
{"name": "QCST 440 Contemporary Issues in Quebec (3 credits)", "prereq": ["qcst-300"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/qcst-440", "subject": "QCST"}
{"name": "QCST 300 Quebec Culture and Society (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/qcst-300", "subject": "QCST"}
{"name": "QCST 336 Quebec Studies Summer Seminar (6 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/qcst-336", "subject": "QCST"}
