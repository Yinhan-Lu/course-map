{"name": "EDPH 689 Teaching and Learning in Higher Education (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/edph-689", "subject": "EDPH"}
