{"name": "AFRI 598 Research Seminar in African Studies (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/afri-598", "subject": "AFRI"}
{"name": "AFRI 481 Special Topics 1 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/afri-481", "subject": "AFRI"}
{"name": "AFRI 499 Arts Internships: African Studies (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/afri-499", "subject": "AFRI"}
{"name": "AFRI 200 Introduction to African Studies (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/afri-200", "subject": "AFRI"}
{"name": "AFRI 480 Honours Thesis (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/afri-480", "subject": "AFRI"}
{"name": "AFRI 401 Swahili Language and Culture (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/afri-401", "subject": "AFRI"}
