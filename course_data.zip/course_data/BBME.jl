{"name": "BBME 697 Thesis Research 4 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-697", "subject": "BBME"}
{"name": "BBME 701 Ph.D. Comprehensive Examination", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-701", "subject": "BBME"}
{"name": "BBME 696 Thesis Research 3 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-696", "subject": "BBME"}
{"name": "BBME 695 Thesis Submission (12 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-695", "subject": "BBME"}
{"name": "BBME 694 Thesis Research 2 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-694", "subject": "BBME"}
{"name": "BBME 693 Thesis Research 1 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-693", "subject": "BBME"}
{"name": "BBME 681 Internship 1 (9 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-681", "subject": "BBME"}
{"name": "BBME 600N2 Seminars in Biological and Biomedical Engineering (1.5 credits)", "prereq": ["bbme-600n1"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-600n2", "subject": "BBME"}
{"name": "BBME 600N1 Seminars in Biological and Biomedical Engineering (1.5 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-600n1", "subject": "BBME"}
{"name": "BBME 682 Internship 2\r (9 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-682", "subject": "BBME"}
{"name": "BBME 600D1 Seminars in Biological and Biomedical Engineering (1.5 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-600d1", "subject": "BBME"}
{"name": "BBME 600D2 Seminars in Biological and Biomedical Engineering (1.5 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/bbme-600d2", "subject": "BBME"}
