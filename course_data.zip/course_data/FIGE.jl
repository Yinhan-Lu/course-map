{"name": "FIGE JS08", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fige-js08", "subject": "FIGE"}
{"name": "FIGE JS07", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fige-js07", "subject": "FIGE"}
{"name": "FIGE JS06", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fige-js06", "subject": "FIGE"}
{"name": "FIGE KN01 Keynote Presentation", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fige-kn01", "subject": "FIGE"}
{"name": "FIGE JS05", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fige-js05", "subject": "FIGE"}
{"name": "FIGE JS04 Community & School Success", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fige-js04", "subject": "FIGE"}
{"name": "FIGE JS02 Opportunities for Youth Action", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fige-js02", "subject": "FIGE"}
{"name": "FIGE JS03 To Be a Leader", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fige-js03", "subject": "FIGE"}
{"name": "FIGE JS01 Novice & Veteran Teachers", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fige-js01", "subject": "FIGE"}
