{"name": "DUMY 100A  (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/dumy-100a", "subject": "DUMY"}
{"name": "DUMY 100  (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/dumy-100", "subject": "DUMY"}
