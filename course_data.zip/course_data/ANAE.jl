{"name": "ANAE 301 TCP Anesthesia (2 credits)", "term": "Winter 2025, Summer 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/anae-301", "subject": "ANAE"}
