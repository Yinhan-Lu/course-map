{"name": "IPEA 503 Managing Interprofessional Conflict", "prereq": ["ipea-500", "ipea-501", "ipea-502"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/ipea-503", "subject": "IPEA"}
{"name": "IPEA 500 Roles in Interprofessional Teams", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/ipea-500", "subject": "IPEA"}
{"name": "IPEA 501 Communication in Interprofessional Teams", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/ipea-501", "subject": "IPEA"}
{"name": "IPEA 502 Patient-Centred Care in Action", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/ipea-502", "subject": "IPEA"}
