{"name": "CCTX 511 Taxation 1 (3 credits)", "prereq": ["cacc-521", "cacc-520"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cctx-511", "subject": "CCTX"}
{"name": "CCTX 532 Taxation 2 (3 credits)", "prereq": ["cctx-511"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/cctx-532", "subject": "CCTX"}
