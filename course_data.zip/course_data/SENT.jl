{"name": "SENT 499 Internship: Social Entrepreneurship (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/sent-499", "subject": "SENT"}
