{"name": "MDST 400 Interdisciplinary Seminar in Medieval Studies (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mdst-400", "subject": "MDST"}
