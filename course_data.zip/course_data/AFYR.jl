{"name": "AFYR 102 Complex Problems 2 (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/afyr-102", "subject": "AFYR"}
{"name": "AFYR 101 Complex Problems 1 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/afyr-101", "subject": "AFYR"}
