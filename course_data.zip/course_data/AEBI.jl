{"name": "AEBI 427 Barbados Interdisciplinary Project (6 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-427", "subject": "AEBI"}
{"name": "AEBI 665 Fundamentals in Advanced Bioimaging (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-665", "subject": "AEBI"}
{"name": "AEBI 425 Tropical Energy and Food (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-425", "subject": "AEBI"}
{"name": "AEBI 423 Sustainable Land Use (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-423", "subject": "AEBI"}
{"name": "AEBI 421 Tropical Horticultural Ecology (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-421", "subject": "AEBI"}
{"name": "AEBI 212 Evolution and Phylogeny (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-212", "subject": "AEBI"}
{"name": "AEBI 211 Organisms 2 (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-211", "subject": "AEBI"}
{"name": "AEBI 120 General Biology (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-120", "subject": "AEBI"}
{"name": "AEBI 210 Organisms 1 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-210", "subject": "AEBI"}
{"name": "AEBI 122 Cell Biology (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aebi-122", "subject": "AEBI"}
