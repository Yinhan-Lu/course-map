{"name": "PROC 124D1 Judicial Institutions and Civil Procedure (2 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/proc-124d1", "subject": "PROC"}
{"name": "PROC 200 Advanced Civil Law Obligations (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/proc-200", "subject": "PROC"}
{"name": "PROC 459 Civil Litigation Workshop (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/proc-459", "subject": "PROC"}
{"name": "PROC 549 Lease, Enterprise, Suretyship (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/proc-549", "subject": "PROC"}
{"name": "PROC 124 Judicial Institutions and Civil Procedure (4 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/proc-124", "subject": "PROC"}
{"name": "PROC 124D2 Judicial Institutions and Civil Procedure (2 credits)", "prereq": ["proc-124d1"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/proc-124d2", "subject": "PROC"}
