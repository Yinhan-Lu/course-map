{"name": "EDPT 204 Creating and Using Media for Learning (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/edpt-204", "subject": "EDPT"}
{"name": "EDPT 200 Integrating Educational Technology in Classrooms (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/edpt-200", "subject": "EDPT"}
