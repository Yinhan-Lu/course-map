{"name": "AEPH 122 Physics Laboratory 2 (1 credit)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aeph-122", "subject": "AEPH"}
{"name": "AEPH 115 Physics 2 (4 credits)", "prereq": ["aeph-112", "aeph-113", "phys-131"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aeph-115", "subject": "AEPH"}
{"name": "AEPH 120 Physics Laboratory 1 (1 credit)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aeph-120", "subject": "AEPH"}
{"name": "AEPH 113 Physics 1 (4 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aeph-113", "subject": "AEPH"}
{"name": "AEPH 112 Introductory Physics 1 (4 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/aeph-112", "subject": "AEPH"}
{"name": "AEPH 114 Introductory Physics 2 (4 credits)", "prereq": ["aeph-112", "aeph-113", "phys-101", "phys-131"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/aeph-114", "subject": "AEPH"}
