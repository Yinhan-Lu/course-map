{"name": "MPQM 760  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpqm-760", "subject": "MPQM"}
{"name": "MPQM 762  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpqm-762", "subject": "MPQM"}
{"name": "MPQM 761  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpqm-761", "subject": "MPQM"}
