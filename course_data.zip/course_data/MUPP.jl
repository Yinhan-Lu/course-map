{"name": "MUPP 693 Performance Practice Seminar 4 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mupp-693", "subject": "MUPP"}
{"name": "MUPP 695 Performance Practice Seminar 6 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mupp-695", "subject": "MUPP"}
{"name": "MUPP 694 Performance Practice Seminar 5 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mupp-694", "subject": "MUPP"}
{"name": "MUPP 692 Performance Practice Seminar 3 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mupp-692", "subject": "MUPP"}
{"name": "MUPP 691 Performance Practice Seminar 2 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mupp-691", "subject": "MUPP"}
{"name": "MUPP 690 Performance Practice Seminar 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mupp-690", "subject": "MUPP"}
{"name": "MUPP 381 Topics in Performance Practice (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/mupp-381", "subject": "MUPP"}
