{"name": "MPHE 751 Joint PhD H.E.C. 12 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-751", "subject": "MPHE"}
{"name": "MPHE 750 Joint PhD H.E.C. 11 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-750", "subject": "MPHE"}
{"name": "MPHE 749 Joint PhD H.E.C. 10 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-749", "subject": "MPHE"}
{"name": "MPHE 748 Joint PhD H.E.C. 9 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-748", "subject": "MPHE"}
{"name": "MPHE 747 Joint PhD H.E.C. 8 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-747", "subject": "MPHE"}
{"name": "MPHE 746  (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-746", "subject": "MPHE"}
{"name": "MPHE 740  (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-740", "subject": "MPHE"}
{"name": "MPHE 745  (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-745", "subject": "MPHE"}
{"name": "MPHE 744  (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-744", "subject": "MPHE"}
{"name": "MPHE 743  (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-743", "subject": "MPHE"}
{"name": "MPHE 742  (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-742", "subject": "MPHE"}
{"name": "MPHE 741  (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mphe-741", "subject": "MPHE"}
