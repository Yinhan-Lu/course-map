{"name": "FSCI 500 Science Communication and Outreach (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-500", "subject": "FSCI"}
{"name": "FSCI 398D1 Research Project in Science Teaching and Learning 3 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-398d1", "subject": "FSCI"}
{"name": "FSCI 444 Barbados Research Project (6 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-444", "subject": "FSCI"}
{"name": "FSCI 400 Field Practicum", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-400", "subject": "FSCI"}
{"name": "FSCI 398D2 Research Project in Science Teaching and Learning 3 (3 credits)", "prereq": ["fsci-398d1"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-398d2", "subject": "FSCI"}
{"name": "FSCI 200 Industrial Practicum 1", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-200", "subject": "FSCI"}
{"name": "FSCI 397 Research Project in Science Teaching and Learning 2 (3 credits)", "prereq": ["fsci-396"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-397", "subject": "FSCI"}
{"name": "FSCI 396 Research Project in Science Teaching and Learning\r 1 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-396", "subject": "FSCI"}
{"name": "FSCI 342 Experiential Learning \u2013 Language", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-342", "subject": "FSCI"}
{"name": "FSCI 300 Industrial Practicum 2", "prereq": ["fsci-200"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-300", "subject": "FSCI"}
{"name": "FSCI 198 Climate Crisis and Climate Actions (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/fsci-198", "subject": "FSCI"}
