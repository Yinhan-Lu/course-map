{"name": "MUEN 573 Baroque Orchestra (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-573", "subject": "MUEN"}
{"name": "MUEN 572 Cappella Antica (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-572", "subject": "MUEN"}
{"name": "MUEN 571 Jazz Combo Project (0.5 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-571", "subject": "MUEN"}
{"name": "MUEN 570 Jazz Combo (1 credit)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-570", "subject": "MUEN"}
{"name": "MUEN 565 String Quartet Seminar (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-565", "subject": "MUEN"}
{"name": "MUEN 563 Jazz Vocal Workshop (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-563", "subject": "MUEN"}
{"name": "MUEN 564 Conducting Workshop (1 credit)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-564", "subject": "MUEN"}
{"name": "MUEN 568 Multiple Ensemble 1 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-568", "subject": "MUEN"}
{"name": "MUEN 567 Beethoven Orchestra (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-567", "subject": "MUEN"}
{"name": "MUEN 569 Tabla Ensemble (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-569", "subject": "MUEN"}
{"name": "MUEN 561 2nd Chamber Music Ensemble (1 credit)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-561", "subject": "MUEN"}
{"name": "MUEN 562 Guitar Ensemble (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-562", "subject": "MUEN"}
{"name": "MUEN 597 McGill Symphony Orchestra (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-597", "subject": "MUEN"}
{"name": "MUEN 596 Opera Repetiteur (2 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-596", "subject": "MUEN"}
{"name": "MUEN 595 Jazz Ensembles (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-595", "subject": "MUEN"}
{"name": "MUEN 594 Contemporary Music Ensemble (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-594", "subject": "MUEN"}
{"name": "MUEN 591 Brass Consort (1 credit)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-591", "subject": "MUEN"}
{"name": "MUEN 590 McGill Wind Orchestra (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-590", "subject": "MUEN"}
{"name": "MUEN 593 Choral Ensembles (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-593", "subject": "MUEN"}
{"name": "MUEN 589 Woodwind Ensembles (1 credit)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-589", "subject": "MUEN"}
{"name": "MUEN 592 Chamber Jazz Ensemble (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-592", "subject": "MUEN"}
{"name": "MUEN 588 Multiple Ensemble 2 (1 credit)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-588", "subject": "MUEN"}
{"name": "MUEN 587 Cappella McGill (2 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-587", "subject": "MUEN"}
{"name": "MUEN 582 Piano Ensembles (1 credit)", "prereq": ["muen-581"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-582", "subject": "MUEN"}
{"name": "MUEN 581 Introduction to Ensemble Playing for Pianists (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-581", "subject": "MUEN"}
{"name": "MUEN 580 Early Music Ensemble (1 credit)", "prereq": ["mupg-272"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-580", "subject": "MUEN"}
{"name": "MUEN 586 Opera Coaching (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-586", "subject": "MUEN"}
{"name": "MUEN 584 Studio Accompanying (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-584", "subject": "MUEN"}
{"name": "MUEN 585 Sonata Masterclass (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-585", "subject": "MUEN"}
{"name": "MUEN 579 Song Interpretation 2 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-579", "subject": "MUEN"}
{"name": "MUEN 578 Song Interpretation 1 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-578", "subject": "MUEN"}
{"name": "MUEN 574 Afro-Cuban/Brazilian Jazz Combo (1 credit)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-574", "subject": "MUEN"}
{"name": "MUEN 560 Chamber Music Ensemble (1 credit)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-560", "subject": "MUEN"}
{"name": "MUEN 654 Opera Repertoire Experience (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-654", "subject": "MUEN"}
{"name": "MUEN 684 Studio Accompanying (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-684", "subject": "MUEN"}
{"name": "MUEN 696 Opera Theatre (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-696", "subject": "MUEN"}
{"name": "MUEN 688 Multiple Ensembles (2 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-688", "subject": "MUEN"}
{"name": "MUEN 599 Jazz Studio Orchestra (1 credit)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-599", "subject": "MUEN"}
{"name": "MUEN 598 Percussion Ensembles (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-598", "subject": "MUEN"}
{"name": "MUEN 556 Introduction to Collaborative Piano 1 (1 credit)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-556", "subject": "MUEN"}
{"name": "MUEN 496 Opera Studio (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-496", "subject": "MUEN"}
{"name": "MUEN 557 Introduction to Collaborative Piano 2 (1 credit)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-557", "subject": "MUEN"}
{"name": "MUEN 541 Chamber Music Project 2 (0.5 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-541", "subject": "MUEN"}
{"name": "MUEN 540 Chamber Music Project 1 (0.5 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-540", "subject": "MUEN"}
{"name": "MUEN 553 Vocal Chamber Ensemble (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-553", "subject": "MUEN"}
{"name": "MUEN 454 Introductory Opera Repertoire Experience (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muen-454", "subject": "MUEN"}
