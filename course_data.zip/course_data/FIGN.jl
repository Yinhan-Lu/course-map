{"name": "FIGN SFTK", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fign-sftk", "subject": "FIGN"}
{"name": "FIGN CPRT CPR Training for Nurses", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/fign-cprt", "subject": "FIGN"}
{"name": "FIGN MPST Moving Patients Safely Training", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/fign-mpst", "subject": "FIGN"}
