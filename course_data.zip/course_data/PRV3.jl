{"name": "PRV3 534 Remedies (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/prv3-534", "subject": "PRV3"}
{"name": "PRV3 200 Advanced Common Law Obligations (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/prv3-200", "subject": "PRV3"}
