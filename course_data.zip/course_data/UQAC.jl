{"name": "UQAC 206  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-206", "subject": "UQAC"}
{"name": "UQAC 205  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-205", "subject": "UQAC"}
{"name": "UQAC 156  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-156", "subject": "UQAC"}
{"name": "UQAC 155 Anal&Int-donn\u00e9es quant psych I (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-155", "subject": "UQAC"}
{"name": "UQAC 202 Natation et securite (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-202", "subject": "UQAC"}
{"name": "UQAC 201  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-201", "subject": "UQAC"}
{"name": "UQAC 186  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-186", "subject": "UQAC"}
{"name": "UQAC 152  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-152", "subject": "UQAC"}
{"name": "UQAC 148  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-148", "subject": "UQAC"}
{"name": "UQAC 329 Psychologie de la sexualit\u00e9 (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-329", "subject": "UQAC"}
{"name": "UQAC 333  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-333", "subject": "UQAC"}
{"name": "UQAC 328  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-328", "subject": "UQAC"}
{"name": "UQAC 812  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-812", "subject": "UQAC"}
{"name": "UQAC 674  (7 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-674", "subject": "UQAC"}
{"name": "UQAC 673 Stage sp\u00e9cialis\u00e9 en physioth\u00e9rapie III (7 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-673", "subject": "UQAC"}
{"name": "UQAC 672 Stage sp\u00e9cialis\u00e9 en physioth\u00e9rapie II (7 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-672", "subject": "UQAC"}
{"name": "UQAC 660 R\u00e9adaptation Cardiorespiratoire (5 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-660", "subject": "UQAC"}
{"name": "UQAC 583 Stage clinique en physioth\u00e9rapie (7 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-583", "subject": "UQAC"}
{"name": "UQAC 611 M\u00e9thodologie avanc\u00e9e de la recherche (4 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-611", "subject": "UQAC"}
{"name": "UQAC 671  (7 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-671", "subject": "UQAC"}
{"name": "UQAC 612 M\u00e9thodologie avanc\u00e9e de la recherche (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-612", "subject": "UQAC"}
{"name": "UQAC 429  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-429", "subject": "UQAC"}
{"name": "UQAC 324 Introduction \u00e0 la psychologie sportive (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-324", "subject": "UQAC"}
{"name": "UQAC 320  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-320", "subject": "UQAC"}
{"name": "UQAC 319 Physiologie de l\u2019homme en movement (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-319", "subject": "UQAC"}
{"name": "UQAC 317 Fondements de la dynamique familiale (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-317", "subject": "UQAC"}
{"name": "UQAC 305  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-305", "subject": "UQAC"}
{"name": "UQAC 318  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-318", "subject": "UQAC"}
{"name": "UQAC 255 Analyse et interpr\u00e9tation de donn\u00e9es quantitatives en psychologie II (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-255", "subject": "UQAC"}
{"name": "UQAC 248  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-248", "subject": "UQAC"}
{"name": "UQAC 246 Psychologie g\u00e9rontologique (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-246", "subject": "UQAC"}
{"name": "UQAC 243  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-243", "subject": "UQAC"}
{"name": "UQAC 244  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-244", "subject": "UQAC"}
{"name": "UQAC 215  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-215", "subject": "UQAC"}
{"name": "UQAC 222  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-222", "subject": "UQAC"}
{"name": "UQAC 245  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-245", "subject": "UQAC"}
{"name": "UQAC 210  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-210", "subject": "UQAC"}
{"name": "UQAC 216  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-216", "subject": "UQAC"}
{"name": "UQAC 128  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-128", "subject": "UQAC"}
{"name": "UQAC 127  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-127", "subject": "UQAC"}
{"name": "UQAC 147  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-147", "subject": "UQAC"}
{"name": "UQAC 207  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-207", "subject": "UQAC"}
{"name": "UQAC 135 Psychologie du d\u00e9veloppement de l'adolescent (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-135", "subject": "UQAC"}
{"name": "UQAC 130 Psychologie sociale (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-130", "subject": "UQAC"}
{"name": "UQAC 145  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-145", "subject": "UQAC"}
{"name": "UQAC 144  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-144", "subject": "UQAC"}
{"name": "UQAC 125  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-125", "subject": "UQAC"}
{"name": "UQAC 124  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-124", "subject": "UQAC"}
{"name": "UQAC 123 Psychologie de l'apprentissage (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-123", "subject": "UQAC"}
{"name": "UQAC 121  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-121", "subject": "UQAC"}
{"name": "UQAC 120  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-120", "subject": "UQAC"}
{"name": "UQAC 119  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-119", "subject": "UQAC"}
{"name": "UQAC 1200  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-1200", "subject": "UQAC"}
{"name": "UQAC 116  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-116", "subject": "UQAC"}
{"name": "UQAC 114  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-114", "subject": "UQAC"}
{"name": "UQAC 112  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-112", "subject": "UQAC"}
{"name": "UQAC 113  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-113", "subject": "UQAC"}
{"name": "UQAC 104  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-104", "subject": "UQAC"}
{"name": "UQAC 109  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-109", "subject": "UQAC"}
{"name": "UQAC 103  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-103", "subject": "UQAC"}
{"name": "UQAC 1060  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-1060", "subject": "UQAC"}
{"name": "UQAC 111  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-111", "subject": "UQAC"}
{"name": "UQAC 106  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-106", "subject": "UQAC"}
{"name": "UQAC 105 Principes de Management (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-105", "subject": "UQAC"}
{"name": "UQAC 110  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-110", "subject": "UQAC"}
{"name": "UQAC 100 Alimentation et activit\u00e9 physique (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-100", "subject": "UQAC"}
{"name": "UQAC 024  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-024", "subject": "UQAC"}
{"name": "UQAC 101  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-101", "subject": "UQAC"}
{"name": "UQAC 023  (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-023", "subject": "UQAC"}
{"name": "UQAC 102  (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/uqac-102", "subject": "UQAC"}
