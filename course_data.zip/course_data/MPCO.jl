{"name": "MPCO 724  (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpco-724", "subject": "MPCO"}
{"name": "MPCO 725 Joint PhD Concordia 6 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpco-725", "subject": "MPCO"}
{"name": "MPCO 723 Joint PhD Concordia 4 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpco-723", "subject": "MPCO"}
{"name": "MPCO 722 Joint PhD Concordia 3 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpco-722", "subject": "MPCO"}
{"name": "MPCO 721 Joint PhD Concordia 2 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpco-721", "subject": "MPCO"}
{"name": "MPCO 720 Joint PhD Concordia 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpco-720", "subject": "MPCO"}
