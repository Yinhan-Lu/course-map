{"name": "PRAC 511 Advanced Mooting 2 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/prac-511", "subject": "PRAC"}
{"name": "PRAC 510D2 Advanced Mooting 1 (1.5 credits)", "prereq": ["prac-510d1"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/prac-510d2", "subject": "PRAC"}
{"name": "PRAC 510D1 Advanced Mooting 1 (1.5 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/prac-510d1", "subject": "PRAC"}
{"name": "PRAC 510 Advanced Mooting 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/prac-510", "subject": "PRAC"}
{"name": "PRAC 200 Advocacy (1 credit)", "prereq": ["prac-147d1", "prac-147d2"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/prac-200", "subject": "PRAC"}
