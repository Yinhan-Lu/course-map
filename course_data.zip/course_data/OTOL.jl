{"name": "OTOL 692 M.Sc. Thesis 3 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/otol-692", "subject": "OTOL"}
{"name": "OTOL 694 M.Sc. Thesis 5 (12 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/otol-694", "subject": "OTOL"}
{"name": "OTOL 691 M.Sc. Thesis 2 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/otol-691", "subject": "OTOL"}
{"name": "OTOL 612 Physiology, Histopathology and Clinical Otolaryngology 2 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/otol-612", "subject": "OTOL"}
{"name": "OTOL 693 M.Sc. Thesis 4 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/otol-693", "subject": "OTOL"}
{"name": "OTOL 690 M.Sc. Thesis 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/otol-690", "subject": "OTOL"}
{"name": "OTOL 603 Advanced Scientific Principles - Otolaryngology 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/otol-603", "subject": "OTOL"}
{"name": "OTOL 602 Physiology, Histopathology and Clinical Otolaryngology 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/otol-602", "subject": "OTOL"}
{"name": "OTOL 613 Advanced Scientific Principles - Otolaryngology 2 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/otol-613", "subject": "OTOL"}
