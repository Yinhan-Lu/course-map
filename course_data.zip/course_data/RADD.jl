{"name": "RADD 301 TCP Radiology (1 credit)", "term": "Winter 2025, Summer 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/radd-301", "subject": "RADD"}
