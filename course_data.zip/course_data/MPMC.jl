{"name": "MPMC 421 Exploitation en souterrain (3 credits)", "term": "Summer 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpmc-421", "subject": "MPMC"}
{"name": "MPMC 330 G\u00e9otechnique mini\u00e8re (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpmc-330", "subject": "MPMC"}
{"name": "MPMC 328 Environnement et gestion des rejets miniers (3 credits)", "term": "Summer 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpmc-328", "subject": "MPMC"}
{"name": "MPMC 329 G\u00e9ologie mini\u00e8re (2 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpmc-329", "subject": "MPMC"}
{"name": "MPMC 326 Recherche op\u00e9rationnelle I (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpmc-326", "subject": "MPMC"}
{"name": "MPMC 321 M\u00e9canique des roches et contr\u00f4le des terrains (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpmc-321", "subject": "MPMC"}
{"name": "MPMC 320 CAO et informatique pour les mines (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/mpmc-320", "subject": "MPMC"}
