{"name": "MUIN 276 Practical Lessons Performance Minor 6 (1.5 credits)", "prereq": ["muin-275"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-276", "subject": "MUIN"}
{"name": "MUIN 280 BMus Practical Lessons 3 (2.5 credits)", "prereq": ["muin-181"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-280", "subject": "MUIN"}
{"name": "MUIN 382 BMus Performance Examination 2 (1 credit)", "prereq": ["muin-282"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-382", "subject": "MUIN"}
{"name": "MUIN 381 BMus Practical Lessons 6 (2.5 credits)", "prereq": ["muin-380"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-381", "subject": "MUIN"}
{"name": "MUIN 380 BMus Practical Lessons 5 (2.5 credits)", "prereq": ["muin-281"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-380", "subject": "MUIN"}
{"name": "MUIN 369 Concerto", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-369", "subject": "MUIN"}
{"name": "MUIN 352 L.Mus. Performance 2 Examination (4 credits)", "prereq": ["muin-252"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-352", "subject": "MUIN"}
{"name": "MUIN 351 L.Mus. Practical Instruction 4 (6 credits)", "prereq": ["muin-350"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-351", "subject": "MUIN"}
{"name": "MUIN 350 L.Mus. Practical Instruction 3 (6 credits)", "prereq": ["muin-251"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-350", "subject": "MUIN"}
{"name": "MUIN 332 Performance 2 Examination", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-332", "subject": "MUIN"}
{"name": "MUIN 333 Piano Techniques 2", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-333", "subject": "MUIN"}
{"name": "MUIN 342 Honours Performance 2 Examination", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-342", "subject": "MUIN"}
{"name": "MUIN 322 Concentration 2 Examination", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-322", "subject": "MUIN"}
{"name": "MUIN 305 Early Music Minor Repertoire Coaching 4 (1.5 credits)", "prereq": ["muin-304"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-305", "subject": "MUIN"}
{"name": "MUIN 304 Early Music Minor Repertoire Coaching 3 (1.5 credits)", "prereq": ["muin-303"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-304", "subject": "MUIN"}
{"name": "MUIN 303 Early Music Minor Repertoire Coaching 2 (1.5 credits)", "prereq": ["muin-302"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-303", "subject": "MUIN"}
{"name": "MUIN 283 BMus Concentration Final Examination (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-283", "subject": "MUIN"}
{"name": "MUIN 302 Early Music Minor Repertoire Coaching 1 (1.5 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-302", "subject": "MUIN"}
{"name": "MUIN 300 Voice Coaching 1 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-300", "subject": "MUIN"}
{"name": "MUIN 282 BMus Performance Examination 1 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-282", "subject": "MUIN"}
{"name": "MUIN 281 BMus Practical Lessons 4 (2.5 credits)", "prereq": ["muin-280"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-281", "subject": "MUIN"}
{"name": "MUIN 301 Voice Coaching 2 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-301", "subject": "MUIN"}
{"name": "MUIN 500 Practical Instruction 1 (1 credit)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-500", "subject": "MUIN"}
{"name": "MUIN 482 BMus Performance Examination 3 (2 credits)", "prereq": ["muin-382"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-482", "subject": "MUIN"}
{"name": "MUIN 562 Artist Diploma Recital 2", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-562", "subject": "MUIN"}
{"name": "MUIN 561 Artist Diploma Practical Instruction 4 (8 credits)", "prereq": ["muin-560"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-561", "subject": "MUIN"}
{"name": "MUIN 481 BMus Practical Lessons 8 (2 credits)", "prereq": ["muin-480"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-481", "subject": "MUIN"}
{"name": "MUIN 560 Artist Diploma Practical Instruction 3 (8 credits)", "prereq": ["muin-461"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-560", "subject": "MUIN"}
{"name": "MUIN 480 BMus Practical Lessons 7 (2 credits)", "prereq": ["muin-381"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-480", "subject": "MUIN"}
{"name": "MUIN 462 Artist Diploma Recital 1", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-462", "subject": "MUIN"}
{"name": "MUIN 452D2 L.Mus. Performance 3 Examination (4 credits)", "prereq": ["muin-452d1"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-452d2", "subject": "MUIN"}
{"name": "MUIN 452D1 L.Mus. Performance 3 Examination (4 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-452d1", "subject": "MUIN"}
{"name": "MUIN 469 Artist Diploma Concerto 1 (1 credit)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-469", "subject": "MUIN"}
{"name": "MUIN 452 L.Mus. Performance 3 Examination (8 credits)", "prereq": ["muin-352"], "term": "Winter 2025, Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-452", "subject": "MUIN"}
{"name": "MUIN 451 L.Mus. Practical Instruction 6 (4 credits)", "prereq": ["muin-450"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-451", "subject": "MUIN"}
{"name": "MUIN 450 L.Mus. Practical Instruction 5 (4 credits)", "prereq": ["muin-351"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-450", "subject": "MUIN"}
{"name": "MUIN 442 Honours Performance 3 Examination", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-442", "subject": "MUIN"}
{"name": "MUIN 432 Performance 3 Examination", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-432", "subject": "MUIN"}
{"name": "MUIN 433 Piano Techniques 3", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-433", "subject": "MUIN"}
{"name": "MUIN 401 Voice Coaching 4 (2 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-401", "subject": "MUIN"}
{"name": "MUIN 384 Conducting Minor Project (1 credit)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-384", "subject": "MUIN"}
{"name": "MUIN 400 Voice Coaching 3 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-400", "subject": "MUIN"}
{"name": "MUIN 630 Conducting Tutorial 1 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-630", "subject": "MUIN"}
{"name": "MUIN 628D2 Jazz Performance/Composition Tutorial 3 (1.5 credits)", "prereq": ["muin-628d1"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-628d2", "subject": "MUIN"}
{"name": "MUIN 628 Jazz Performance/Composition Tutorial 3 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-628", "subject": "MUIN"}
{"name": "MUIN 627 Jazz Performance/Composition Tutorial 2 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-627", "subject": "MUIN"}
{"name": "MUIN 624 Performance Tutorial 5 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-624", "subject": "MUIN"}
{"name": "MUIN 623 Performance Tutorial 4 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-623", "subject": "MUIN"}
{"name": "MUIN 628D1 Jazz Performance/Composition Tutorial 3 (1.5 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-628d1", "subject": "MUIN"}
{"name": "MUIN 626 Jazz Performance/Composition Tutorial 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-626", "subject": "MUIN"}
{"name": "MUIN 622D2 Performance Tutorial 3 (1.5 credits)", "prereq": ["muin-622d1"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-622d2", "subject": "MUIN"}
{"name": "MUIN 622 Performance Tutorial 3 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-622", "subject": "MUIN"}
{"name": "MUIN 622D1 Performance Tutorial 3 (1.5 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-622d1", "subject": "MUIN"}
{"name": "MUIN 612 Vocal Coaching 3 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-612", "subject": "MUIN"}
{"name": "MUIN 621 Performance Tutorial 2 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-621", "subject": "MUIN"}
{"name": "MUIN 611 Vocal Coaching 2 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-611", "subject": "MUIN"}
{"name": "MUIN 610 Vocal Coaching 1 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-610", "subject": "MUIN"}
{"name": "MUIN 620 Performance Tutorial 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-620", "subject": "MUIN"}
{"name": "MUIN 601 Graduate Diploma Vocal Coaching 2 (2 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-601", "subject": "MUIN"}
{"name": "MUIN 600 Graduate Diploma Vocal Coaching 1 (2 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-600", "subject": "MUIN"}
{"name": "MUIN 569 Artist Diploma Concerto 2 (1 credit)", "prereq": ["muin-469"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-569", "subject": "MUIN"}
{"name": "MUIN 563 Artist Diploma Recital 3", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-563", "subject": "MUIN"}
{"name": "MUIN 724 D.Mus. Performance Tutorial 5 (4 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-724", "subject": "MUIN"}
{"name": "MUIN 726 D.Mus. Performance Tutorial 7 (4 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-726", "subject": "MUIN"}
{"name": "MUIN 725 D.Mus. Performance Tutorial 6 (4 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-725", "subject": "MUIN"}
{"name": "MUIN 723 D.Mus. Performance Tutorial 4 (4 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-723", "subject": "MUIN"}
{"name": "MUIN 722 D.Mus. Performance Tutorial 3 (4 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-722", "subject": "MUIN"}
{"name": "MUIN 721 D.Mus. Performance Tutorial 2 (4 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-721", "subject": "MUIN"}
{"name": "MUIN 720 D.Mus. Performance Tutorial 1 (4 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-720", "subject": "MUIN"}
{"name": "MUIN 716 Post-Graduate Artist Diploma Tutorial 2 (8 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-716", "subject": "MUIN"}
{"name": "MUIN 702 Doctoral Repertoire Coaching 3 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-702", "subject": "MUIN"}
{"name": "MUIN 703 Doctoral Repertoire Coaching 4 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-703", "subject": "MUIN"}
{"name": "MUIN 715 Post-Graduate Artist Diploma Tutorial 1 (8 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-715", "subject": "MUIN"}
{"name": "MUIN 701 Doctoral Repertoire Coaching 2 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-701", "subject": "MUIN"}
{"name": "MUIN 700 Doctoral Repertoire Coaching 1 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-700", "subject": "MUIN"}
{"name": "MUIN 637 Graduate Certificate Conducting Tutorial 1\r (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-637", "subject": "MUIN"}
{"name": "MUIN 635 Graduate Diploma Tutorial 2 (8 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-635", "subject": "MUIN"}
{"name": "MUIN 634 Graduate Diploma Tutorial 1 (8 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-634", "subject": "MUIN"}
{"name": "MUIN 632 Conducting Tutorial 3 (3 credits)", "prereq": ["muin-631"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-632", "subject": "MUIN"}
{"name": "MUIN 631 Conducting Tutorial 2 (3 credits)", "prereq": ["muin-630"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-631", "subject": "MUIN"}
{"name": "MUIN 633 Conducting Tutorial 4 (3 credits)", "prereq": ["muin-632"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-633", "subject": "MUIN"}
{"name": "MUIN 638 Graduate Certificate Conducting Tutorial 2 (3 credits)", "prereq": ["muin-637"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-638", "subject": "MUIN"}
{"name": "MUIN 734 D.Mus. Performance Tutorial 12 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-734", "subject": "MUIN"}
{"name": "MUIN 733 D.Mus. Performance Tutorial 11 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-733", "subject": "MUIN"}
{"name": "MUIN 732 D.Mus. Performance Tutorial 10 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-732", "subject": "MUIN"}
{"name": "MUIN 731 D.Mus. Performance Tutorial 9 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-731", "subject": "MUIN"}
{"name": "MUIN 730 D.Mus. Performance Tutorial 8 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-730", "subject": "MUIN"}
{"name": "MUIN 275 Practical Lessons Performance Minor 5 (1.5 credits)", "prereq": ["muin-274"], "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-275", "subject": "MUIN"}
{"name": "MUIN 272 Performance Minor Examination 1", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-272", "subject": "MUIN"}
{"name": "MUIN 274 Practical Lessons Performance Minor 4 (1.5 credits)", "prereq": ["muin-273"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-274", "subject": "MUIN"}
{"name": "MUIN 273 Practical Lessons Performance Minor 3 (1.5 credits)", "prereq": ["muin-270"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-273", "subject": "MUIN"}
{"name": "MUIN 269 Classical Concerto Exam (1 credit)", "prereq": ["muin-232"], "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-269", "subject": "MUIN"}
{"name": "MUIN 270 Practical Lessons Performance Minor 1 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-270", "subject": "MUIN"}
{"name": "MUIN 252 L.Mus. Performance 1 Examination (4 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-252", "subject": "MUIN"}
{"name": "MUIN 251 L.Mus. Practical Instruction 2 (6 credits)", "prereq": ["muin-250"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-251", "subject": "MUIN"}
{"name": "MUIN 271 Practical Lessons Performance Minor 2 (3 credits)", "prereq": ["muin-270"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-271", "subject": "MUIN"}
{"name": "MUIN 250 L.Mus. Practical Instruction 1 (6 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-250", "subject": "MUIN"}
{"name": "MUIN 222 Concentration 1 Examination", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-222", "subject": "MUIN"}
{"name": "MUIN 232 Performance 1 Examination", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-232", "subject": "MUIN"}
{"name": "MUIN 181 BMus Practical Lessons 2 (3 credits)", "prereq": ["muin-180"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-181", "subject": "MUIN"}
{"name": "MUIN 180 BMus Practical Lessons 1 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-180", "subject": "MUIN"}
{"name": "MUIN 210 Elective Practical Instruction 3 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-210", "subject": "MUIN"}
{"name": "MUIN 211 Elective Practical Instruction 4 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-211", "subject": "MUIN"}
{"name": "MUIN 111 Elective Practical Instruction 2 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-111", "subject": "MUIN"}
{"name": "MUIN 110 Elective Practical Instruction 1 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/muin-110", "subject": "MUIN"}
