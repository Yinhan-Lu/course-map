{"name": "FAES 402 Honours Research Project 2 (6 credits)", "prereq": ["faes-401"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-402", "subject": "FAES"}
{"name": "FAES 406 Honours Project 2 (3 credits)", "prereq": ["faes-405"], "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-406", "subject": "FAES"}
{"name": "FAES 401 Honours Research Project 1 (6 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-401", "subject": "FAES"}
{"name": "FAES 405 Honours Project 1 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-405", "subject": "FAES"}
{"name": "FAES 323 Special Topics 04 (3 credits)", "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-323", "subject": "FAES"}
{"name": "FAES 313 Special Topics 03 (3 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-313", "subject": "FAES"}
{"name": "FAES 372 Special Topics 02 (2 credits)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-372", "subject": "FAES"}
{"name": "FAES 310 Agribusiness Entrepreneurship (3 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-310", "subject": "FAES"}
{"name": "FAES 371 Special Topics 01 (1 credit)", "term": "Fall 2024, Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-371", "subject": "FAES"}
{"name": "FAES 301 Internship 2B (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-301", "subject": "FAES"}
{"name": "FAES 301D1 Internship 2B (1.5 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-301d1", "subject": "FAES"}
{"name": "FAES 301D2 Internship 2B (1.5 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-301d2", "subject": "FAES"}
{"name": "FAES 200 Internship 1", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-200", "subject": "FAES"}
{"name": "FAES 300 Internship 2 (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-300", "subject": "FAES"}
{"name": "FAES 201 Internship 1B", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-201", "subject": "FAES"}
{"name": "FAES 300D1 Internship 2 (1.5 credits)", "term": "This course is not scheduled for the 2024-2025 academic year.", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-300d1", "subject": "FAES"}
{"name": "FAES 300D2 Internship 2 (1.5 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/faes-300d2", "subject": "FAES"}
