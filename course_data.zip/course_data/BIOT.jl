{"name": "BIOT 505 Selected Topics in Biotechnology (3 credits)", "term": "Fall 2024", "link": "https://www.mcgill.ca/study/2024-2025/courses/biot-505", "subject": "BIOT"}
{"name": "BIOT 302 Introduction to Synthetic\r Biology (3 credits)", "prereq": ["biol-201"], "term": "Winter 2025", "link": "https://www.mcgill.ca/study/2024-2025/courses/biot-302", "subject": "BIOT"}
